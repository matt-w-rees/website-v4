---
title: "Change this publication at content/publications/"
authors:
- Your Full Name
- Another Researcher
date: "2018-09-01"

publication: "Journal of Machine Learning"

# You can have multiple links
# format is, LINK_NAME : LINK_URL
links:
    pdf: https://github.com/hadisinaee/avicenna
    code: https://github.com/hadisinaee/avicenna
    slides: https://github.com/hadisinaee/avicenna
    video: https://github.com/hadisinaee/avicenna

---


[See the wiki page for tutorial!](https://github.com/hadisinaee/avicenna/wiki)