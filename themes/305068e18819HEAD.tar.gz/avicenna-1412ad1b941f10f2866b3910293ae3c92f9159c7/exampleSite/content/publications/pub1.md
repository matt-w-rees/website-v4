---
title: "Your Paper Name Goes Here"
authors:
- Your Full Name
- Another Researcher
date: "2018-09-01"

publication: "Journal of Machine Learning"

links:
    pdf: https://github.com/hadisinaee/avicenna
    code: https://github.com/hadisinaee/avicenna
    slides: https://github.com/hadisinaee/avicenna
    video: https://github.com/hadisinaee/avicenna

---

