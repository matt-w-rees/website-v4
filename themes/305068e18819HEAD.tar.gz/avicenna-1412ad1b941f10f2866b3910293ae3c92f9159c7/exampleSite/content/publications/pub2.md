---
title: "Your Paper Name Goes Here"
authors:
- Your Full Name
- Author Name
date: "2016-09-01"

publication: "Journal of Machine Learning"

links:
    pdf: https://github.com/hadisinaee/avicenna
    code: https://github.com/hadisinaee/avicenna
    slides: https://github.com/hadisinaee/avicenna
    video: https://github.com/hadisinaee/avicenna
---