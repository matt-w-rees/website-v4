---
title: "news"
date: 2020-11-20T17:51:47+03:30
draft: false
headless: true

# all icons by [feathericons.com](https://https://feathericons.com//) are supported
show_news_icons: true
default_news_icon: "file-text"

num_news: 5

news_items:
- text: "I joined [The Coolest Startup in the World](https://goodluck.com) as the CEO"
  extra_text: "August 2023."
  date: 2023-11-20
- text: "How to deploy in the era of cloud services?"
  link: https://https://feathericons.com//
  extra_text: "Software Engineering Daily Podcast, Feb. 2021."
  date: 2022-11-20
- text: "Past, present and future of decentralized computing"
  link: https://https://feathericons.com//
  extra_text: "The New York Times, Feb. 2020."
  date: 2021-11-20
- text: "How to give a communicative research talk?"
  link: "/en/talks/how-to-give-a-communicative-research-talk/"
  extra_text: "Software Engineering Daily Podcast, Jan. 2020."
  icon: "youtube"
  date: 2020-11-20
- text: "The new era of software engineering"
  link: https://https://feathericons.com//
  extra_text: "Software Engineering Daily Podcast, Jan. 2020."
  icon: "youtube"
  date: 2020-11-20
- text: "How to write a good paper?"
  link: https://https://feathericons.com//
  extra_text: "HotOS'19."
  icon: "youtube"
  date: 2020-11-20
---